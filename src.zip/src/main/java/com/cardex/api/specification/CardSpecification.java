package com.cardex.api.specification;

import com.cardex.api.entity.CardEntity;
import com.cardex.api.enumeration.CardCondition;
import com.cardex.api.enumeration.CardLanguage;
import com.cardex.api.entity.UserEntity;
import org.springframework.data.jpa.domain.Specification;

public final class CardSpecification {

    private CardSpecification() {
    }

    public static Specification<CardEntity> nameContains(String name) {
        return (root, query, criteriaBuilder) -> {
            if (name == null || name.isBlank()) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("name")),
                    "%" + name.trim().toLowerCase() + "%"
            );
        };
    }

    public static Specification<CardEntity> languageEquals(
            CardLanguage language
    ) {
        return (root, query, criteriaBuilder) -> {
            if (language == null) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.equal(
                    root.get("language"),
                    language
            );
        };
    }

    public static Specification<CardEntity> conditionEquals(
            CardCondition condition
    ) {
        return (root, query, criteriaBuilder) -> {
            if (condition == null) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.equal(
                    root.get("condition"),
                    condition
            );
        };
    }

    public static Specification<CardEntity> favoriteEquals(Boolean favorite) {
        return (root, query, criteriaBuilder) -> {
            if (favorite == null) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.equal(
                    root.get("favorite"),
                    favorite
            );
        };
    }

    public static Specification<CardEntity> userEquals(UserEntity user) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.equal(
                        root.get("user"),
                        user
                );
    }
    public static Specification<CardEntity> collectionContains(
            String collection
    ) {
        return (root, query, criteriaBuilder) -> {
            if (collection == null || collection.isBlank()) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("collectionName")),
                    "%" + collection.trim().toLowerCase() + "%"
            );
        };
    }

    public static Specification<CardEntity> rarityContains(
            String rarity
    ) {
        return (root, query, criteriaBuilder) -> {
            if (rarity == null || rarity.isBlank()) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("rarity")),
                    "%" + rarity.trim().toLowerCase() + "%"
            );
        };
    }

    public static Specification<CardEntity> numberContains(
            String number
    ) {
        return (root, query, criteriaBuilder) -> {
            if (number == null || number.isBlank()) {
                return criteriaBuilder.conjunction();
            }

            return criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("cardNumber")),
                    "%" + number.trim().toLowerCase() + "%"
            );
        };
    }
}