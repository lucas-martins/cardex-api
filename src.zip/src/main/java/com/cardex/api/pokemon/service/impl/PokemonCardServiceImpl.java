package com.cardex.api.pokemon.service.impl;

import com.cardex.api.entity.CardEntity;
import com.cardex.api.entity.PokemonCardCatalogEntity;
import com.cardex.api.entity.UserEntity;
import com.cardex.api.entity.WishlistCardEntity;
import com.cardex.api.exception.PokemonTcgApiUnavailableException;
import com.cardex.api.pokemon.client.PokemonTcgClient;
import com.cardex.api.pokemon.dto.PokemonCardApiResponse;
import com.cardex.api.pokemon.mapper.PokemonCardMapper;
import com.cardex.api.pokemon.response.PokemonCardSearchPageResponse;
import com.cardex.api.pokemon.response.PokemonCardSearchResponse;
import com.cardex.api.pokemon.service.PokemonCardService;
import com.cardex.api.repository.CardRepository;
import com.cardex.api.repository.WishlistCardRepository;
import com.cardex.api.service.AuthenticatedUserService;
import com.cardex.api.service.PokemonCardCatalogService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PokemonCardServiceImpl
        implements PokemonCardService {

    private final PokemonTcgClient pokemonTcgClient;
    private final PokemonCardMapper pokemonCardMapper;
    private final PokemonCardCatalogService pokemonCardCatalogService;
    private final CardRepository cardRepository;
    private final WishlistCardRepository wishlistCardRepository;
    private final AuthenticatedUserService authenticatedUserService;

    @Override
    public PokemonCardSearchPageResponse searchByName(
            String name,
            int page,
            int size
    ) {
        UserEntity authenticatedUser =
                authenticatedUserService.getAuthenticatedUser();

        try {
            PokemonCardApiResponse apiResponse =
                    pokemonTcgClient.searchByName(
                            name,
                            page,
                            size
                    );

            if (apiResponse == null
                    || apiResponse.data() == null) {
                return emptyResponse(
                        page,
                        size
                );
            }

            pokemonCardCatalogService.cacheCards(
                    apiResponse.data()
            );

            List<PokemonCardSearchResponse> baseCards =
                    apiResponse.data()
                            .stream()
                            .map(
                                    pokemonCardMapper::toSearchResponse
                            )
                            .toList();

            List<PokemonCardSearchResponse> cards =
                    enrichWithUserState(
                            baseCards,
                            authenticatedUser
                    );

            int totalElements =
                    apiResponse.totalCount() != null
                            ? apiResponse.totalCount()
                            : 0;

            int totalPages =
                    size > 0
                            ? (int) Math.ceil(
                            (double) totalElements
                            / size
                    )
                            : 0;

            return new PokemonCardSearchPageResponse(
                    cards,
                    apiResponse.page(),
                    apiResponse.pageSize(),
                    apiResponse.count(),
                    totalElements,
                    totalPages,
                    apiResponse.page() == 1,
                    totalPages == 0
                            || apiResponse.page()
                            >= totalPages
            );
        } catch (
                PokemonTcgApiUnavailableException exception
        ) {
            return searchFromLocalCatalog(
                    name,
                    page,
                    size,
                    authenticatedUser,
                    exception
            );
        }
    }

    private PokemonCardSearchPageResponse searchFromLocalCatalog(
            String name,
            int page,
            int size,
            UserEntity authenticatedUser,
            PokemonTcgApiUnavailableException exception
    ) {
        Page<PokemonCardCatalogEntity> localPage =
                pokemonCardCatalogService.searchByName(
                        name,
                        page,
                        size
                );

        if (localPage.isEmpty()) {
            throw exception;
        }

        List<PokemonCardSearchResponse> baseCards =
                localPage
                        .getContent()
                        .stream()
                        .map(
                                pokemonCardMapper::toSearchResponse
                        )
                        .toList();

        List<PokemonCardSearchResponse> cards =
                enrichWithUserState(
                        baseCards,
                        authenticatedUser
                );

        return new PokemonCardSearchPageResponse(
                cards,
                page,
                size,
                cards.size(),
                (int) localPage.getTotalElements(),
                localPage.getTotalPages(),
                localPage.isFirst(),
                localPage.isLast()
        );
    }

    private List<PokemonCardSearchResponse> enrichWithUserState(
            List<PokemonCardSearchResponse> cards,
            UserEntity authenticatedUser
    ) {
        if (cards.isEmpty()) {
            return cards;
        }

        List<String> externalIds =
                cards
                        .stream()
                        .map(
                                PokemonCardSearchResponse::externalId
                        )
                        .distinct()
                        .toList();

        Map<String, CardEntity> ownedCardsByExternalId =
                cardRepository
                        .findByUserAndExternalIdIn(
                                authenticatedUser,
                                externalIds
                        )
                        .stream()
                        .collect(
                                Collectors.toMap(
                                        CardEntity::getExternalId,
                                        Function.identity(),
                                        (first, second) -> first
                                )
                        );

        Map<String, WishlistCardEntity> wishlistCardsByExternalId =
                wishlistCardRepository
                        .findByUserAndExternalIdIn(
                                authenticatedUser,
                                externalIds
                        )
                        .stream()
                        .collect(
                                Collectors.toMap(
                                        WishlistCardEntity::getExternalId,
                                        Function.identity(),
                                        (first, second) -> first
                                )
                        );

        return cards
                .stream()
                .map(card -> {
                    CardEntity ownedCard =
                            ownedCardsByExternalId.get(
                                    card.externalId()
                            );

                    WishlistCardEntity wishlistCard =
                            wishlistCardsByExternalId.get(
                                    card.externalId()
                            );

                    return new PokemonCardSearchResponse(
                            card.externalId(),
                            card.name(),
                            card.collectionName(),
                            card.cardNumber(),
                            card.rarity(),
                            card.imageUrl(),
                            ownedCard != null,
                            ownedCard != null
                                    ? ownedCard.getId()
                                    : null,
                            wishlistCard != null,
                            wishlistCard != null
                                    ? wishlistCard.getId()
                                    : null,
                            wishlistCard != null
                                    ? wishlistCard.getPriority()
                                    : null
                    );
                })
                .toList();
    }

    private PokemonCardSearchPageResponse emptyResponse(
            int page,
            int size
    ) {
        return new PokemonCardSearchPageResponse(
                List.of(),
                page,
                size,
                0,
                0,
                0,
                page == 1,
                true
        );
    }
}